package id.kotlin.training.movies.view.base

interface View {

    fun onAttach()

    fun onDetach()
}