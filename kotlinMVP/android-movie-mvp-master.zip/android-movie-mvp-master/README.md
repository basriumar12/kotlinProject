# Android Movie MVP
Android Movie MVP Architecture
